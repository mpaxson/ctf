#!/usr/bin/env python3
import socketserver
import struct

# NOTE: This is not the real key.  The server has the real key.
KEY = 0x0
IV = 0x35f5c00b


class Cipher(object):
    """ Class that can encrypt and decrypt with a customer cipher.

        This cipher is a substitution permutation network.  It has a 64 bit key
        and a 32 bit IV.  For a given block (32 bits):
            - XOR with the IV
            - XOR with the low 32 bits of the key
            - Run through the sbox
            - XOR with the high 32 bits of the key

        Multiple blocks are encrypted with CBC.
    """

    SBOX = [0xF, 0x1, 0x3, 0x9, 0xB, 0x6, 0x2, 0x8,
            0xC, 0x5, 0xE, 0xA, 0x4, 0x0, 0x7, 0xD]

    SBOX_INV = [0]*16
    for index, value in enumerate(SBOX):
        SBOX_INV[value] = index

    def __init__(self, key, iv):
        self.key1 = key & 0xFFFFFFFF
        self.key2 = (key & 0xFFFFFFFF00000000) >> 32
        self.iv = iv & 0xFFFFFFFF

    @classmethod
    def _sbox(cls, plaintext):
        result = bytearray()
        for chunk in plaintext.to_bytes(4, 'big'):
            low_nibble = cls.SBOX[chunk & 0x0F]
            high_nibble = cls.SBOX[(chunk & 0xF0) >> 4] << 4
            result.append(low_nibble | high_nibble)
        return int.from_bytes(result, 'big')

    @classmethod
    def _i_sbox(cls, ciphertext):
        result = bytearray()
        for chunk in ciphertext.to_bytes(4, 'big'):
            low_nibble = cls.SBOX_INV[chunk & 0x0F]
            high_nibble = cls.SBOX_INV[(chunk & 0xF0) >> 4] << 4
            result.append(low_nibble | high_nibble)
        return int.from_bytes(result, 'big')

    def _encrypt_block(self, plaintext, curr_iv):
        plaintext &= 0xFFFFFFFF
        ciphertext = plaintext ^ curr_iv
        ciphertext ^= self.key1
        ciphertext = self._sbox(ciphertext)
        ciphertext ^= self.key2
        return ciphertext

    def _decrypt_block(self, ciphertext, curr_iv):
        ciphertext &= 0xFFFFFFFF
        plaintext = ciphertext ^ self.key2
        plaintext = self._i_sbox(plaintext)
        plaintext ^= self.key1
        plaintext ^= curr_iv
        return plaintext

    def encrypt(self, plaintext):
        ciphertext = []
        iv = self.iv
        for block in plaintext:
            ciphertext_block = self._encrypt_block(block, iv)
            ciphertext.append(ciphertext_block)
            iv = ciphertext_block
        return ciphertext

    def decrypt(self, ciphertext):
        plaintext = []
        iv = self.iv
        for block in ciphertext:
            plaintext_block = self._decrypt_block(block, iv)
            plaintext.append(plaintext_block)
            iv = block
        return plaintext


class Handler(socketserver.BaseRequestHandler):
    """ This server is an oracle that will decrypt messages sent.
        The protocol is a 4 byte big-endian length, followed by the message.
        The server will pad the message to be 4-byte aligned, encrypt it,
        and respond with the ciphertext.
    """

    def handle(self):
        length_bytes = self.request.recv(4)
        length = struct.unpack('>I', length_bytes)[0]
        plaintext = self.recv_n(length)

        cipher = Cipher(KEY, IV)
        plaintext_list = partition(plaintext)
        ciphertext_list = cipher.encrypt(plaintext_list)
        ciphertext = coalesce(ciphertext_list)

        self.request.sendall(ciphertext)

    def recv_n(self, length):
        data = b''
        while len(data) < length:
            data += self.request.recv(length - len(data))
        return data


def partition(buff):
    buff_list = []
    if len(buff) % 4 != 0:
        buff += b'\x00' * (4 - (len(buff) % 4))
    for i in range(0, int(len(buff) / 4)):
        buff_list.append(struct.unpack('>I', buff[i*4:(i+1)*4])[0])
    return buff_list


def coalesce(buff_list):
    buff = b''
    for item in buff_list:
        buff += struct.pack('>I', item)
    return buff


class ThreadedTcpServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    pass


def main():
    server = ThreadedTcpServer(('0.0.0.0', 7623), Handler)
    try:
        server.serve_forever()
    except (SystemExit, KeyboardInterrupt):
        server.shutdown()
        server.server_close()

if __name__ == '__main__':
    main()
