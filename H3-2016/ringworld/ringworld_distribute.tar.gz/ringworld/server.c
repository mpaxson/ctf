#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdint.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>

#include "common.h"

#define RINGBUFLEN 4096

char ringbuf[RINGBUFLEN] __attribute__((aligned(RINGBUFLEN)));
char *rq_read_ptr = ringbuf + 22;
char *rq_write_ptr = ringbuf + 22;

/* Copy len bytes from ringbuf into destination buffer */
ssize_t ringbuf_read(void *dst, size_t len)
{
	if (len > RINGBUFLEN) {
		return -1;
	}

	if ((rq_read_ptr + len - 1) <= (ringbuf + RINGBUFLEN - 1)) {
		memcpy(dst, rq_read_ptr, len);
		return len;
	}
	else {
		size_t ending = (ringbuf + RINGBUFLEN - 1) - rq_read_ptr;
		size_t beginning = len - ending;
		memcpy(dst, rq_read_ptr, ending);
		memcpy(dst+ending, ringbuf, beginning);
		return len;
	}

	return -1;
}

ssize_t ringbuf_write(void *src, size_t len)
{
	if (len > RINGBUFLEN) {
		return -1;
	}

	if ((rq_write_ptr + len - 1) <= (ringbuf + RINGBUFLEN - 1)) {
		memcpy(rq_write_ptr, src, len);
		rq_write_ptr += len;
		return len;
	}
	else {
		size_t ending = (ringbuf + RINGBUFLEN - 1) - rq_write_ptr;
		size_t beginning = len - ending;
		memcpy(rq_write_ptr, src, ending);
		memcpy(ringbuf, src, beginning);
		rq_write_ptr =  ringbuf + beginning;
		return len;
	}

	return -1;
}

void increment_rq_read_ptr(size_t step)
{
	rq_read_ptr = ringbuf + (((uintptr_t)(rq_read_ptr + step)) % RINGBUFLEN);
}

int is_flag_valid() {
	char tmpbuf[1024];
	ringbuf_read(tmpbuf, 1024);
	return (strnlen(tmpbuf, 1024) > 0);
}

int main(int argc, char **argv)
{
	char tmpbuf[1024];
	FILE *fp = fopen("flag.txt", "r");
	if (!fp) {
		exit(-1);
	}
	char *res = fgets(tmpbuf, 1024, fp);
	if (!res) {
		exit(-1);
	}
	tmpbuf[1023] = '\0';

	int flaglen = strnlen(tmpbuf, 1023) + 1;
	ringbuf_write(tmpbuf, flaglen);

	if (!is_flag_valid()) {
		fprintf(stderr, "Invalid flag!\n");
	}
	increment_rq_read_ptr(flaglen);

	int sock = socket(AF_INET, SOCK_STREAM, 0);
	int client_sock;
	struct sockaddr_in client_addr;
	socklen_t addr_len = sizeof(client_addr);
	struct sockaddr_in sa = {
		.sin_family = AF_INET,
		.sin_port = htons(1337),
		.sin_addr.s_addr = htonl(INADDR_ANY)
	};
	bind(sock, (struct sockaddr *)&sa, sizeof(sa));
	listen(sock, 5);

	for(;;) {
		client_sock = accept(sock, (struct sockaddr *)&client_addr, &addr_len);
		pid_t pid = fork();
		if (pid == 0) {
			request_t rq;
			recv(client_sock, &rq, sizeof(rq), 0);
			rq.msg_len = ntohl(rq.msg_len);
			if (rq.msg_len > RINGBUFLEN) {
				/* ERROR! */
				return -1;
			}
			rq.type = ntohl(rq.type);

			ringbuf_write(&rq, sizeof(rq));
			ssize_t rcvd_len = recv(client_sock, tmpbuf, 1024, 0);
			if (rcvd_len > 0) {
				ringbuf_write(tmpbuf, rcvd_len);
			} else {
				/* ERROR! */
				return -1;
			}

			char *response = malloc(rq.msg_len);
			increment_rq_read_ptr(sizeof(rq));
			ringbuf_read(response, rq.msg_len);
			for (int i = 0; i < rq.msg_len; i++) {
				if (isalpha(response[i])) {
					response[i] &= ~0x20;
				}
			}
			send(client_sock, response, rq.msg_len, 0);

			free(response);
			close(client_sock);
			exit(0);
		} else if (pid > 0){
			/* in parent */
			close(client_sock);
		} else {
			/* ERROR */
		}
	}
	return 0;
}
