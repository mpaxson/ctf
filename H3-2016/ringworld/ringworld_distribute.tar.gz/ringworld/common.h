#ifndef COMMON_H
#define COMMON_H

typedef struct request {
	size_t msg_len;
	int type;
	char msg[0];
} __attribute__((packed)) request_t;

#endif
